INSERT my_table2 (id, name) VALUES (7, 'Seven');
INSERT my_table2 (id, name)
    VALUES (8, 'Eight');
